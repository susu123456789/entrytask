from locust import HttpLocust,TaskSet,task


class test_wsy(TaskSet):
    @task()
    def test_baidu(self):
        r = self.client.get("/",timeout=30)
        assert r.status_code == 200


class websitUser(HttpLocust):
    task_set = test_wsy
    min_wait = 3000
    max_wait = 6000


